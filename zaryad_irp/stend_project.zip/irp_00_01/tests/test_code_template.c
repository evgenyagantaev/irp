// here is a unit's under test interface
//#include "ProductionCode.h"

#include "unity.h"

void setUp(void)
{
  // This is run before EACH TEST
}

void tearDown(void)
{
}

void test_some_function(void)
{
  /* All of these should pass */
  TEST_ASSERT_EQUAL(3, 2);
}



