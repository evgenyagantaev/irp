/*
 * main.h
 *
 *  Created on: Sep 2, 2016
 *      Author: root
 */

#ifndef INC_MAIN_H_
#define INC_MAIN_H_

#include <stdint.h>

#endif /* INC_MAIN_H_ */
