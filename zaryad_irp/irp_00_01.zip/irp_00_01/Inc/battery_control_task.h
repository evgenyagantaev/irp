/*
 * battery_control_task.h
 *
 *  Created on: Aug 24, 2016
 *      Author: root
 */

#ifndef INC_BATTERY_CONTROL_TASK_H_
#define INC_BATTERY_CONTROL_TASK_H_

static int emergency_turn_off_flag = 0;


void battery_control_task();

#endif /* INC_BATTERY_CONTROL_TASK_H_ */
