/*
 * int_adc_measure_task.h
 *
 *  Created on: Aug 24, 2016
 *      Author: root
 */

#ifndef INC_PRESENTATION_ADC_MEASURE_TASK_H_
#define INC_PRESENTATION_ADC_MEASURE_TASK_H_

void presentation_adc_measure_task();

#endif /* INC_PRESENTATION_ADC_MEASURE_TASK_H_ */
