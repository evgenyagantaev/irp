/*
 * constant_adc_measure_task.h
 *
 *  Created on: Jun 29, 2022
 *      Author: agant
 */

#ifndef INC_CONSTANT_ADC_MEASURE_TASK_H_
#define INC_CONSTANT_ADC_MEASURE_TASK_H_

void constant_adc_measure_task();

#endif /* INC_CONSTANT_ADC_MEASURE_TASK_H_ */
