/*
 * button_interpreter_task.h
 *
 *  Created on: Sep 5, 2016
 *      Author: root
 */

#ifndef INC_BUTTON_INTERPRETER_TASK_H_
#define INC_BUTTON_INTERPRETER_TASK_H_

#include "stdint.h"

static int command_sent;    //
static int interpreter_state;

void button_interpreter_task();


#endif /* INC_BUTTON_INTERPRETER_TASK_H_ */
