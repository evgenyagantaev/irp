/*
 * button_polling_task.h
 *
 *  Created on: Sep 3, 2016
 *      Author: root
 */

#ifndef INC_BUTTON_POLLING_TASK_H_
#define INC_BUTTON_POLLING_TASK_H_

#include "stdint.h"


void button_polling_task();

#endif /* INC_BUTTON_POLLING_TASK_H_ */
