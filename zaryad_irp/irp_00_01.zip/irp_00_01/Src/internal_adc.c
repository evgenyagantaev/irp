/*
 * internal_adc.c
 *
 *  Created on: Aug 24, 2016
 *      Author: root
 */

#include "internal_adc.h"

int32_t int_adc_measure_ch0() // returns voltage in milivolts
{
    return 999;
}
int32_t int_adc_measure_ch1() // returns voltage in milivolts
{
    return 999;
}
int32_t int_adc_measure_ch2() // returns voltage in milivolts
{
    return 999;
}
